-- ═══════════════════════════════════════════════
--  เฮงเฮง ปังจัง — Setup SQL
--  รันใน phpMyAdmin: http://203.170.192.192/phpmyadmin
--  DB: xnca_hengheng_merchant
-- ═══════════════════════════════════════════════

-- Admin User (ถ้ายังไม่มี)
CREATE TABLE IF NOT EXISTS AdminUser (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    createdAt DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Insert default admin (skip if exists)
INSERT IGNORE INTO AdminUser (username, password) VALUES ('admin', 'admin1234');

-- Campaign
CREATE TABLE IF NOT EXISTS Campaign (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL DEFAULT 'เฮงเฮง ปังจัง Lucky Draw',
    description TEXT,
    endDate DATE,
    totalPrizeValue INT DEFAULT 0,
    createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
    updatedAt DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Merchant
CREATE TABLE IF NOT EXISTS Merchant (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    ownerName VARCHAR(255),
    phone VARCHAR(20),
    address TEXT,
    lat DECIMAL(10,7),
    lng DECIMAL(10,7),
    status ENUM('pending','approved','rejected') DEFAULT 'pending',
    lineUserId VARCHAR(100),
    createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
    updatedAt DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_status (status),
    INDEX idx_phone (phone)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Receipt
CREATE TABLE IF NOT EXISTS Receipt (
    id INT AUTO_INCREMENT PRIMARY KEY,
    merchantId INT,
    bagCount INT DEFAULT 1,
    imageUrl VARCHAR(500),
    status ENUM('pending','approved','rejected') DEFAULT 'pending',
    reviewNote TEXT,
    reviewedAt DATETIME,
    createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_status (status),
    INDEX idx_merchant (merchantId),
    FOREIGN KEY (merchantId) REFERENCES Merchant(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Merchant Quota
CREATE TABLE IF NOT EXISTS MerchantQuota (
    id INT AUTO_INCREMENT PRIMARY KEY,
    merchantId INT NOT NULL,
    totalQR INT DEFAULT 0,
    remainingQR INT DEFAULT 0,
    createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
    updatedAt DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uk_merchant (merchantId),
    FOREIGN KEY (merchantId) REFERENCES Merchant(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Digital Ticket
CREATE TABLE IF NOT EXISTS DigitalTicket (
    id INT AUTO_INCREMENT PRIMARY KEY,
    ticketCode VARCHAR(10) NOT NULL UNIQUE,
    merchantId INT,
    customerName VARCHAR(255),
    customerPhone VARCHAR(20),
    status ENUM('unclaimed','activated','used','expired') DEFAULT 'unclaimed',
    isWinner TINYINT(1) DEFAULT 0,
    claimedAt DATETIME,
    createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_status (status),
    INDEX idx_merchant (merchantId),
    INDEX idx_winner (isWinner),
    INDEX idx_customer_phone (customerPhone),
    FOREIGN KEY (merchantId) REFERENCES Merchant(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- OTP Code
CREATE TABLE IF NOT EXISTS OtpCode (
    id INT AUTO_INCREMENT PRIMARY KEY,
    phone VARCHAR(20) NOT NULL,
    code VARCHAR(6) NOT NULL,
    expiresAt DATETIME NOT NULL,
    verified TINYINT(1) DEFAULT 0,
    createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_phone (phone)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- System Config (key-value)
CREATE TABLE IF NOT EXISTS SystemConfig (
    id INT AUTO_INCREMENT PRIMARY KEY,
    `key` VARCHAR(100) NOT NULL UNIQUE,
    `value` TEXT,
    createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
    updatedAt DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Insert default config
INSERT IGNORE INTO SystemConfig (`key`, `value`) VALUES
    ('app_name', 'เฮงเฮง ปังจัง'),
    ('app_subtitle', 'สะสมแด้น ลุ้นโชคใหญ่!'),
    ('daily_collect_limit', '3'),
    ('gps_radius_m', '20'),
    ('otp_expire_min', '5'),
    ('tickets_per_bag', '30'),
    ('registration_open', 'true'),
    ('prize_total_value', '100000'),
    ('campaign_name', 'เฮงเฮง ปังจัง Lucky Draw 2026'),
    ('campaign_end_date', '2026-12-31');

-- Banner
CREATE TABLE IF NOT EXISTS Banner (
    id INT AUTO_INCREMENT PRIMARY KEY,
    type ENUM('announcement','image','card','sticky','popup','interstitial') DEFAULT 'announcement',
    title VARCHAR(255) NOT NULL,
    body TEXT,
    imageUrl VARCHAR(500),
    bgColor VARCHAR(20),
    linkUrl VARCHAR(500),
    position VARCHAR(30) DEFAULT 'user_hero',
    isActive TINYINT(1) DEFAULT 1,
    sortOrder INT DEFAULT 0,
    createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_position (position),
    INDEX idx_active (isActive)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- QR Rule (Smart QR Rules)
CREATE TABLE IF NOT EXISTS QrRule (
    id INT AUTO_INCREMENT PRIMARY KEY,
    type ENUM('time','day_of_week','scan_count','geo') NOT NULL,
    name VARCHAR(255),
    config JSON,
    isActive TINYINT(1) DEFAULT 1,
    createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
    updatedAt DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Gallery Photo
CREATE TABLE IF NOT EXISTS GalleryPhoto (
    id INT AUTO_INCREMENT PRIMARY KEY,
    imageUrl VARCHAR(500) NOT NULL,
    caption VARCHAR(255),
    uploadedBy VARCHAR(100),
    isApproved TINYINT(1) DEFAULT 0,
    createdAt DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
