# เฮงเฮง ปังจัง — PHP Admin Panel

## 📁 โครงสร้างไฟล์

```
hengheng/
├── admin/
│   ├── index.php          ← หน้า Login
│   ├── dashboard.php      ← ภาพรวม KPI (8 cards + กราฟ 7 วัน + กิจกรรมล่าสุด)
│   ├── receipts.php       ← อนุมัติ/ปฏิเสธใบเสร็จ + filter
│   ├── merchants.php      ← จัดการร้านค้า + เพิ่ม QR quota
│   ├── tickets.php        ← ดูฉลาก + ค้นหา + ตั้งผู้โชคดี
│   ├── banners.php        ← สร้าง/ลบ/สลับแบนเนอร์ (9 ตำแหน่ง)
│   ├── config.php         ← ตั้งค่าระบบ + ดูสถานะ DB
│   ├── layout.php         ← Shared layout (sidebar + header)
│   ├── layout_footer.php  ← Footer + mobile bottom nav
│   ├── logout.php         ← ออกจากระบบ
│   └── api/
│       ├── login.php      ← POST login → token (สำหรับ Next.js)
│       ├── stats.php      ← GET KPI stats
│       ├── receipts.php   ← GET/POST receipts
│       ├── merchants.php  ← GET/POST merchants
│       ├── tickets.php    ← GET tickets
│       └── config.php     ← GET/POST system config
├── includes/
│   ├── db.php             ← Database connection (PDO)
│   ├── auth.php           ← Session + token auth
│   └── functions.php      ← Helper functions
├── .htaccess              ← Security + upload limits
└── setup.sql              ← สร้างตาราง + default data
```

## 🚀 วิธีติดตั้ง

### 1. รัน SQL ก่อน
เข้า phpMyAdmin: http://203.170.192.192/phpmyadmin
- เลือก DB: `xnca_hengheng_merchant`
- Import หรือ copy-paste `setup.sql` แล้วรัน

### 2. อัปโหลดไฟล์ไป VPS
```bash
# SSH เข้า VPS
ssh root@203.170.192.192 -p 98

# path บน VPS:
# /home/xnca/domains/xn--72ca9ib1gc.xn--72cac8e8ec.com/public_html/hengheng/
```

อัปโหลดทั้ง folder `admin/` และ `includes/` ไปที่ path ข้างบน
- `.htaccess` วางที่ `/hengheng/.htaccess`

### 3. ทดสอบ
- เข้า: `https://เฮงเฮง.ปังจัง.com/hengheng/admin/`
- Login: `admin` / `admin1234`

### 4. (ถ้าจำเป็น) ตั้ง Vercel Rewrite
เนื่องจาก `เฮงเฮง.ปังจัง.com` CNAME → Vercel  
ต้องเพิ่ม rewrite ใน `vercel.json` ของ Next.js project:

```json
{
  "rewrites": [
    {
      "source": "/hengheng/:path*",
      "destination": "https://203.170.192.192/hengheng/:path*"
    }
  ]
}
```

## 🔐 Login
- **PHP Admin (Web):** Session-based
- **API (Next.js):** Token-based (X-Admin-Token header)
- Default: `admin` / `admin1234`

## 🎨 Design
- Gold Design System: `#F7D37A → #C9963A`
- Dark theme: `#0d1117`
- Font: Kanit
- Responsive: Sidebar (desktop) → Bottom nav (mobile)
