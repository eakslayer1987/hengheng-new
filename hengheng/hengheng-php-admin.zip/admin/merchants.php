<?php
/**
 * admin/merchants.php — จัดการร้านค้า
 */
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
requireAdminLogin();

$msg = '';
$msgType = '';

// ─── Handle Actions ─────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id     = (int)($_POST['id'] ?? 0);
    $action = $_POST['action'] ?? '';

    if ($id && in_array($action, ['approved', 'rejected'])) {
        db_run("UPDATE Merchant SET status = ?, updatedAt = NOW() WHERE id = ?", [$action, $id]);

        // If approved → create initial quota
        if ($action === 'approved') {
            $existing = db_one("SELECT id FROM MerchantQuota WHERE merchantId = ?", [$id]);
            if (!$existing) {
                db_run("INSERT INTO MerchantQuota (merchantId, totalQR, remainingQR, createdAt, updatedAt) VALUES (?, 0, 0, NOW(), NOW())", [$id]);
            }
            $msg = "✅ อนุมัติร้านค้า #{$id}";
        } else {
            $msg = "❌ ปฏิเสธร้านค้า #{$id}";
        }
        $msgType = $action === 'approved' ? 'success' : 'error';
    }

    // Add quota
    if ($id && $action === 'add_quota') {
        $amount = max(0, (int)($_POST['amount'] ?? 0));
        if ($amount > 0) {
            $existing = db_one("SELECT id FROM MerchantQuota WHERE merchantId = ?", [$id]);
            if ($existing) {
                db_run("UPDATE MerchantQuota SET remainingQR = remainingQR + ?, totalQR = totalQR + ?, updatedAt = NOW() WHERE merchantId = ?",
                    [$amount, $amount, $id]);
            } else {
                db_run("INSERT INTO MerchantQuota (merchantId, totalQR, remainingQR, createdAt, updatedAt) VALUES (?, ?, ?, NOW(), NOW())",
                    [$id, $amount, $amount]);
            }
            $msg = "✅ เพิ่ม QR {$amount} ให้ร้าน #{$id}";
            $msgType = 'success';
        }
    }
}

// ─── Filters ─────────────────────────────
$filter = $_GET['status'] ?? 'pending';
$where  = $filter !== 'all' ? "WHERE m.status = ?" : "";
$params = $filter !== 'all' ? [$filter] : [];

$merchants = db_all("
    SELECT m.*, mq.remainingQR, mq.totalQR,
           (SELECT COUNT(*) FROM DigitalTicket WHERE merchantId = m.id AND DATE(createdAt) = CURDATE()) as todayScans
    FROM Merchant m
    LEFT JOIN MerchantQuota mq ON mq.merchantId = m.id
    {$where}
    ORDER BY m.createdAt DESC
    LIMIT 50
", $params);

require_once __DIR__ . '/layout.php';
?>

<div class="page-header">
    <h2>🏪 ร้าน<span>ค้า</span></h2>
    <a href="merchants.php?status=<?= e($filter) ?>" class="btn btn-secondary">🔄 รีเฟรช</a>
</div>

<?php if ($msg): ?>
    <div class="alert alert-<?= $msgType ?>"><?= $msg ?></div>
<?php endif; ?>

<div class="filter-bar">
    <?php foreach (['pending' => '⏳ รอ', 'approved' => '✅ อนุมัติ', 'all' => 'ทั้งหมด'] as $key => $label): ?>
        <a href="merchants.php?status=<?= $key ?>"
           class="filter-btn <?= $filter === $key ? 'active' : '' ?>">
            <?= $label ?>
        </a>
    <?php endforeach; ?>
</div>

<?php if (empty($merchants)): ?>
    <div class="empty-state">ไม่มีร้านค้า</div>
<?php else: ?>
    <?php foreach ($merchants as $m): ?>
    <div class="card" style="margin-bottom:10px">
        <div style="display:flex;justify-content:space-between;gap:12px">
            <div style="flex:1">
                <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin-bottom:4px">
                    <span style="font-size:14px;font-weight:800"><?= e($m['name']) ?></span>
                    <?php
                        $bClass = $m['status'] === 'approved' ? 'badge-green' : ($m['status'] === 'pending' ? 'badge-yellow' : 'badge-red');
                        $bText  = $m['status'] === 'approved' ? '✅ อนุมัติ' : ($m['status'] === 'pending' ? '⏳ รอ' : '❌ ปฏิเสธ');
                    ?>
                    <span class="badge <?= $bClass ?>"><?= $bText ?></span>
                </div>
                <p style="font-size:12px;color:var(--sub)">👤 <?= e($m['ownerName'] ?? '-') ?></p>
                <p style="font-size:12px;color:var(--sub)">📞 <?= e($m['phone'] ?? '-') ?></p>
                <p style="font-size:11px;color:var(--mut);margin-top:2px">📍 <?= e($m['address'] ?? '-') ?></p>
                <?php if ($m['status'] === 'approved'): ?>
                    <p style="font-size:11px;color:var(--sub);margin-top:4px">
                        📱 สแกนวันนี้: <strong style="color:var(--grn)"><?= (int)$m['todayScans'] ?></strong>
                    </p>
                <?php endif; ?>
            </div>
            <div style="text-align:right;flex-shrink:0">
                <p style="font-size:24px;font-weight:900;color:var(--gold)"><?= (int)($m['remainingQR'] ?? 0) ?></p>
                <p style="font-size:9px;color:var(--mut)">QR เหลือ</p>
            </div>
        </div>

        <?php if ($m['status'] === 'pending'): ?>
        <div style="display:flex;gap:8px;margin-top:14px">
            <form method="POST" style="flex:1">
                <input type="hidden" name="id" value="<?= $m['id'] ?>">
                <input type="hidden" name="action" value="approved">
                <button type="submit" class="btn btn-green" style="width:100%;justify-content:center">
                    ✅ อนุมัติ
                </button>
            </form>
            <form method="POST" style="flex:1">
                <input type="hidden" name="id" value="<?= $m['id'] ?>">
                <input type="hidden" name="action" value="rejected">
                <button type="submit" class="btn btn-red" style="width:100%;justify-content:center">
                    ❌ ปฏิเสธ
                </button>
            </form>
        </div>
        <?php endif; ?>

        <?php if ($m['status'] === 'approved'): ?>
        <div style="margin-top:12px;display:flex;gap:8px;align-items:center">
            <form method="POST" style="display:flex;gap:6px;align-items:center;flex:1">
                <input type="hidden" name="id" value="<?= $m['id'] ?>">
                <input type="hidden" name="action" value="add_quota">
                <input type="number" name="amount" placeholder="จำนวน QR" min="1"
                       class="form-input" style="width:120px;padding:6px 10px;font-size:12px">
                <button type="submit" class="btn btn-gold" style="white-space:nowrap">
                    ➕ เพิ่ม QR
                </button>
            </form>
        </div>
        <?php endif; ?>
    </div>
    <?php endforeach; ?>
<?php endif; ?>

<?php require_once __DIR__ . '/layout_footer.php'; ?>
