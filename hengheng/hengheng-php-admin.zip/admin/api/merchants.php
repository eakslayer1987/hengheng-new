<?php
/**
 * admin/api/merchants.php — Merchants API
 * GET  ?status=pending&limit=50 → { merchants: [...] }
 * POST { id, action: 'approved'|'rejected' } → { ok }
 */
require_once __DIR__ . '/../../includes/db.php';
require_once __DIR__ . '/../../includes/auth.php';
require_once __DIR__ . '/../../includes/functions.php';

apiCorsHeaders();
requireApiToken();

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $status = $_GET['status'] ?? 'pending';
    $limit  = min(100, max(1, (int)($_GET['limit'] ?? 50)));

    $where  = $status !== 'all' ? "WHERE m.status = ?" : "";
    $params = $status !== 'all' ? [$status] : [];

    $merchants = db_all("
        SELECT m.*, mq.remainingQR, mq.totalQR
        FROM Merchant m
        LEFT JOIN MerchantQuota mq ON mq.merchantId = m.id
        {$where}
        ORDER BY m.createdAt DESC
        LIMIT {$limit}
    ", $params);

    // Add qrRemaining alias for Next.js compatibility
    foreach ($merchants as &$m) {
        $m['qrRemaining'] = (int)($m['remainingQR'] ?? 0);
    }

    jsonResponse(['merchants' => $merchants]);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $body   = getJsonBody();
    $id     = (int)($body['id'] ?? 0);
    $action = $body['action'] ?? '';

    if (!$id || !in_array($action, ['approved', 'rejected'])) {
        jsonResponse(['error' => 'Invalid params'], 400);
    }

    db_run("UPDATE Merchant SET status = ?, updatedAt = NOW() WHERE id = ?", [$action, $id]);

    if ($action === 'approved') {
        $existing = db_one("SELECT id FROM MerchantQuota WHERE merchantId = ?", [$id]);
        if (!$existing) {
            db_run("INSERT INTO MerchantQuota (merchantId, totalQR, remainingQR, createdAt, updatedAt) VALUES (?, 0, 0, NOW(), NOW())", [$id]);
        }
    }

    jsonResponse(['ok' => true, 'status' => $action]);
}

jsonResponse(['error' => 'Method not allowed'], 405);
