<?php
/**
 * admin/receipts.php — อนุมัติใบเสร็จ
 */
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
requireAdminLogin();

$msg = '';
$msgType = '';

// ─── Handle Actions ─────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id     = (int)($_POST['id'] ?? 0);
    $action = $_POST['action'] ?? '';

    if ($id && in_array($action, ['approve', 'reject'])) {
        $newStatus = $action === 'approve' ? 'approved' : 'rejected';
        db_run("UPDATE Receipt SET status = ?, reviewedAt = NOW() WHERE id = ?", [$newStatus, $id]);

        // If approved → generate tickets (based on bagCount × tickets_per_bag)
        if ($action === 'approve') {
            $receipt = db_one("SELECT * FROM Receipt WHERE id = ?", [$id]);
            if ($receipt) {
                $ticketsPerBag = (int)(db_one("SELECT `value` FROM SystemConfig WHERE `key`='tickets_per_bag'")['value'] ?? 30);
                $totalCodes = $receipt['bagCount'] * $ticketsPerBag;

                // Add to MerchantQuota
                $existing = db_one("SELECT id, remainingQR FROM MerchantQuota WHERE merchantId = ?", [$receipt['merchantId']]);
                if ($existing) {
                    db_run("UPDATE MerchantQuota SET remainingQR = remainingQR + ?, updatedAt = NOW() WHERE id = ?",
                        [$totalCodes, $existing['id']]);
                } else {
                    db_run("INSERT INTO MerchantQuota (merchantId, totalQR, remainingQR, createdAt, updatedAt) VALUES (?, ?, ?, NOW(), NOW())",
                        [$receipt['merchantId'], $totalCodes, $totalCodes]);
                }
            }
            $msg = "✅ อนุมัติใบเสร็จ #{$id} — เพิ่ม {$totalCodes} QR";
            $msgType = 'success';
        } else {
            $msg = "❌ ปฏิเสธใบเสร็จ #{$id}";
            $msgType = 'error';
        }
    }
}

// ─── Filters ─────────────────────────────
$filter = $_GET['status'] ?? 'pending';
$where  = $filter !== 'all' ? "WHERE r.status = ?" : "";
$params = $filter !== 'all' ? [$filter] : [];

$receipts = db_all("
    SELECT r.*, m.name as merchantName, m.ownerName, m.phone as merchantPhone
    FROM Receipt r
    LEFT JOIN Merchant m ON r.merchantId = m.id
    {$where}
    ORDER BY r.createdAt DESC
    LIMIT 50
", $params);

require_once __DIR__ . '/layout.php';
?>

<div class="page-header">
    <h2>📋 ใบ<span>เสร็จ</span></h2>
    <a href="receipts.php?status=<?= e($filter) ?>" class="btn btn-secondary">🔄 รีเฟรช</a>
</div>

<?php if ($msg): ?>
    <div class="alert alert-<?= $msgType ?>"><?= $msg ?></div>
<?php endif; ?>

<!-- Filters -->
<div class="filter-bar">
    <?php foreach (['pending' => '⏳ รอ', 'approved' => '✅ อนุมัติ', 'rejected' => '❌ ปฏิเสธ', 'all' => 'ทั้งหมด'] as $key => $label): ?>
        <a href="receipts.php?status=<?= $key ?>"
           class="filter-btn <?= $filter === $key ? 'active' : '' ?>">
            <?= $label ?>
        </a>
    <?php endforeach; ?>
</div>

<!-- Receipts List -->
<?php if (empty($receipts)): ?>
    <div class="empty-state">ไม่มีรายการ</div>
<?php else: ?>
    <?php foreach ($receipts as $r): ?>
    <div class="card" style="margin-bottom:10px">
        <div style="display:flex;align-items:flex-start;gap:14px">
            <?php if ($r['imageUrl']): ?>
                <img src="<?= e($r['imageUrl']) ?>" class="thumb"
                     onerror="this.style.display='none'">
            <?php endif; ?>
            <div style="flex:1">
                <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin-bottom:4px">
                    <span style="font-size:14px;font-weight:800"><?= e($r['merchantName'] ?? 'ไม่ระบุ') ?></span>
                    <?php
                        $bClass = $r['status'] === 'approved' ? 'badge-green' : ($r['status'] === 'pending' ? 'badge-yellow' : 'badge-red');
                        $bText  = $r['status'] === 'approved' ? '✅ อนุมัติ' : ($r['status'] === 'pending' ? '⏳ รอ' : '❌ ปฏิเสธ');
                    ?>
                    <span class="badge <?= $bClass ?>"><?= $bText ?></span>
                </div>
                <p style="font-size:12px;color:var(--sub)">
                    🛍️ <?= (int)$r['bagCount'] ?> ถุง ·
                    👤 <?= e($r['ownerName'] ?? '-') ?> ·
                    📞 <?= e($r['merchantPhone'] ?? '-') ?>
                </p>
                <p style="font-size:11px;color:var(--mut);margin-top:2px">
                    📅 <?= thaiDate($r['createdAt']) ?>
                </p>
            </div>
        </div>

        <?php if ($r['status'] === 'pending'): ?>
        <div style="display:flex;gap:8px;margin-top:14px">
            <form method="POST" style="flex:1">
                <input type="hidden" name="id" value="<?= $r['id'] ?>">
                <input type="hidden" name="action" value="approve">
                <button type="submit" class="btn btn-green" style="width:100%;justify-content:center">
                    ✅ อนุมัติ
                </button>
            </form>
            <form method="POST" style="flex:1">
                <input type="hidden" name="id" value="<?= $r['id'] ?>">
                <input type="hidden" name="action" value="reject">
                <button type="submit" class="btn btn-red" style="width:100%;justify-content:center">
                    ❌ ปฏิเสธ
                </button>
            </form>
        </div>
        <?php endif; ?>
    </div>
    <?php endforeach; ?>
<?php endif; ?>

<?php require_once __DIR__ . '/layout_footer.php'; ?>
