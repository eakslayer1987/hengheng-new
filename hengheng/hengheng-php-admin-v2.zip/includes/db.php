<?php
/**
 * includes/db.php — Database Connection
 * เฮงเฮง ปังจัง Admin
 */

define('DB_HOST', 'localhost');
define('DB_NAME', 'xnca_hengheng_merchant');
define('DB_USER', 'xnca_hengheng_merchant');
define('DB_PASS', 'BntaXSk96yAkGEUmhA9T');

$pdo = null;

function db(): PDO {
    global $pdo;
    if ($pdo) return $pdo;

    try {
        $pdo = new PDO(
            "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
            DB_USER,
            DB_PASS,
            [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
            ]
        );
    } catch (PDOException $e) {
        http_response_code(500);
        die(json_encode(['error' => 'Database connection failed']));
    }

    return $pdo;
}

/**
 * SELECT all rows
 */
function db_all(string $sql, array $params = []): array {
    $stmt = db()->prepare($sql);
    $stmt->execute($params);
    return $stmt->fetchAll();
}

/**
 * SELECT one row
 */
function db_one(string $sql, array $params = []): ?array {
    $stmt = db()->prepare($sql);
    $stmt->execute($params);
    $row = $stmt->fetch();
    return $row ?: null;
}

/**
 * INSERT / UPDATE / DELETE — returns affected rows
 */
function db_run(string $sql, array $params = []): int {
    $stmt = db()->prepare($sql);
    $stmt->execute($params);
    return $stmt->rowCount();
}

/**
 * INSERT — returns last insert ID
 */
function db_insert(string $sql, array $params = []): string {
    $stmt = db()->prepare($sql);
    $stmt->execute($params);
    return db()->lastInsertId();
}
