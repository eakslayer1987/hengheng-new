<?php
/**
 * includes/auth.php — Session & Token Auth
 * เฮงเฮง ปังจัง Admin
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

define('ADMIN_TOKEN_SECRET', 'hengheng-admin-token-2026');

/**
 * Check if admin is logged in (session-based for web)
 */
function isAdminLoggedIn(): bool {
    return !empty($_SESSION['admin_id']);
}

/**
 * Require admin login — redirect to index.php if not
 */
function requireAdminLogin(): void {
    if (!isAdminLoggedIn()) {
        header('Location: index.php');
        exit;
    }
}

/**
 * Verify admin credentials
 */
function verifyAdmin(string $username, string $password): ?array {
    $admin = db_one("SELECT * FROM AdminUser WHERE username = ?", [$username]);
    if (!$admin) return null;

    // Support both bcrypt and plain text (for initial setup)
    if (password_verify($password, $admin['password']) || $admin['password'] === $password) {
        return $admin;
    }
    return null;
}

/**
 * Generate JWT-like token for API auth
 */
function generateAdminToken(int $adminId): string {
    $payload = base64_encode(json_encode([
        'id'  => $adminId,
        'exp' => time() + 86400, // 24h
        'iat' => time(),
    ]));
    $sig = hash_hmac('sha256', $payload, ADMIN_TOKEN_SECRET);
    return $payload . '.' . $sig;
}

/**
 * Verify API token — returns admin_id or null
 */
function verifyAdminToken(string $token): ?int {
    $parts = explode('.', $token);
    if (count($parts) !== 2) return null;

    [$payload, $sig] = $parts;
    $expected = hash_hmac('sha256', $payload, ADMIN_TOKEN_SECRET);

    if (!hash_equals($expected, $sig)) return null;

    $data = json_decode(base64_decode($payload), true);
    if (!$data || ($data['exp'] ?? 0) < time()) return null;

    return $data['id'] ?? null;
}

/**
 * Require valid API token (from X-Admin-Token header)
 */
function requireApiToken(): int {
    $token = $_SERVER['HTTP_X_ADMIN_TOKEN'] ?? '';
    if (!$token) {
        http_response_code(401);
        die(json_encode(['error' => 'Missing token']));
    }
    $id = verifyAdminToken($token);
    if (!$id) {
        http_response_code(401);
        die(json_encode(['error' => 'Invalid or expired token']));
    }
    return $id;
}

/**
 * CORS headers for API endpoints
 */
function apiCorsHeaders(): void {
    header('Content-Type: application/json; charset=utf-8');
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Headers: Content-Type, X-Admin-Token');
    header('Access-Control-Allow-Methods: GET, POST, PATCH, DELETE, OPTIONS');

    if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
        http_response_code(204);
        exit;
    }
}
