<?php
/**
 * includes/functions.php — Helper Functions
 * เฮงเฮง ปังจัง Admin
 */

/**
 * Format number with commas
 */
function fmt(int $n): string {
    return number_format($n);
}

/**
 * Thai date format
 */
function thaiDate(string $datetime): string {
    $months = ['', 'ม.ค.', 'ก.พ.', 'มี.ค.', 'เม.ย.', 'พ.ค.', 'มิ.ย.',
               'ก.ค.', 'ส.ค.', 'ก.ย.', 'ต.ค.', 'พ.ย.', 'ธ.ค.'];
    $ts = strtotime($datetime);
    $d = (int)date('j', $ts);
    $m = $months[(int)date('n', $ts)];
    $y = (int)date('Y', $ts) + 543;
    $t = date('H:i', $ts);
    return "$d $m " . substr($y, 2) . " $t น.";
}

/**
 * Short Thai date (no time)
 */
function thaiDateShort(string $datetime): string {
    $months = ['', 'ม.ค.', 'ก.พ.', 'มี.ค.', 'เม.ย.', 'พ.ค.', 'มิ.ย.',
               'ก.ค.', 'ส.ค.', 'ก.ย.', 'ต.ค.', 'พ.ย.', 'ธ.ค.'];
    $ts = strtotime($datetime);
    $d = (int)date('j', $ts);
    $m = $months[(int)date('n', $ts)];
    $y = (int)date('Y', $ts) + 543;
    return "$d $m " . substr($y, 2);
}

/**
 * Sanitize output
 */
function e(string $str): string {
    return htmlspecialchars($str, ENT_QUOTES | ENT_HTML5, 'UTF-8');
}

/**
 * JSON response helper
 */
function jsonResponse(array $data, int $code = 200): void {
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

/**
 * Get JSON body from request
 */
function getJsonBody(): array {
    $raw = file_get_contents('php://input');
    return json_decode($raw, true) ?: [];
}

/**
 * Badge HTML
 */
function statusBadge(string $status): string {
    $map = [
        'approved' => ['✅ อนุมัติ',   'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'],
        'pending'  => ['⏳ รอดำเนินการ', 'bg-amber-500/10 text-amber-400 border-amber-500/30'],
        'rejected' => ['❌ ปฏิเสธ',    'bg-red-500/10 text-red-400 border-red-500/30'],
        'activated'=> ['✅ สแกนแล้ว',  'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'],
    ];
    $info = $map[$status] ?? [$status, 'bg-gray-500/10 text-gray-400 border-gray-500/30'];
    return '<span class="inline-block text-xs font-bold px-2 py-0.5 rounded-md border ' . $info[1] . '">' . $info[0] . '</span>';
}
