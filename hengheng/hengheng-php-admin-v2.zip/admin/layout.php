<?php
/**
 * admin/layout.php — Shared Layout
 * Gold Design System: #F7D37A → #C9963A
 */

if (!function_exists('db')) {
    require_once __DIR__ . '/../includes/db.php';
}
if (!function_exists('isAdminLoggedIn')) {
    require_once __DIR__ . '/../includes/auth.php';
}
require_once __DIR__ . '/../includes/functions.php';

// Count pending items for badges
$pendingReceipts  = (int)(db_one("SELECT COUNT(*) as c FROM Receipt WHERE status='pending'")['c'] ?? 0);
$pendingMerchants = (int)(db_one("SELECT COUNT(*) as c FROM Merchant WHERE status='pending'")['c'] ?? 0);
$totalPending = $pendingReceipts + $pendingMerchants;

$currentPage = basename($_SERVER['SCRIPT_NAME'], '.php');
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin — เฮงเฮง ปังจัง</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Kanit:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    <style>
        :root {
            --bg:   #0d1117;
            --bg2:  #161b22;
            --bg3:  #1f2937;
            --gold: #E8B820;
            --gold2:#F5D78E;
            --gold3:#C9963A;
            --gold4:#A67208;
            --red:  #FD1803;
            --grn:  #3fb950;
            --err:  #f85149;
            --blue: #58a6ff;
            --txt:  #e6edf3;
            --sub:  rgba(200,220,255,.6);
            --mut:  rgba(150,170,210,.4);
            --bor:  rgba(255,255,255,.08);
            --bor2: rgba(232,184,32,.3);
        }
        * { margin:0; padding:0; box-sizing:border-box; }
        body {
            font-family: 'Kanit', sans-serif;
            background: var(--bg);
            color: var(--txt);
            min-height: 100dvh;
        }
        a { color: var(--gold); text-decoration: none; }

        /* ─── Layout ─── */
        .admin-wrap {
            display: flex;
            min-height: 100dvh;
        }
        .sidebar {
            width: 220px;
            background: var(--bg2);
            border-right: 1px solid var(--bor);
            padding: 20px 0;
            display: flex;
            flex-direction: column;
            flex-shrink: 0;
            position: sticky;
            top: 0;
            height: 100dvh;
        }
        .sidebar-logo {
            text-align: center;
            padding: 0 16px 20px;
            border-bottom: 1px solid var(--bor);
            margin-bottom: 8px;
        }
        .sidebar-logo h1 {
            font-size: 18px;
            font-weight: 900;
            background: linear-gradient(135deg, var(--gold2), var(--gold4));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        .sidebar-logo p { font-size: 10px; color: var(--mut); margin-top: 2px; }

        .nav-item {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 10px 20px;
            font-size: 13px;
            font-weight: 600;
            color: var(--sub);
            cursor: pointer;
            transition: all .15s;
            border-left: 3px solid transparent;
            text-decoration: none;
        }
        .nav-item:hover {
            background: rgba(255,255,255,.03);
            color: var(--txt);
        }
        .nav-item.active {
            background: rgba(232,184,32,.06);
            color: var(--gold);
            border-left-color: var(--gold);
        }
        .nav-item .emoji { font-size: 16px; width: 22px; text-align: center; }
        .nav-badge {
            margin-left: auto;
            background: var(--err);
            color: #fff;
            font-size: 10px;
            font-weight: 800;
            padding: 1px 6px;
            border-radius: 10px;
            min-width: 18px;
            text-align: center;
        }
        .sidebar-footer {
            margin-top: auto;
            padding: 16px 20px;
            border-top: 1px solid var(--bor);
        }
        .sidebar-footer a {
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 12px;
            color: var(--err);
            font-weight: 600;
        }

        /* ─── Main content ─── */
        .main-content {
            flex: 1;
            padding: 24px;
            min-width: 0;
            overflow-y: auto;
        }
        .page-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 20px;
        }
        .page-header h2 {
            font-size: 22px;
            font-weight: 900;
        }
        .page-header h2 span { color: var(--gold); }

        /* ─── Cards ─── */
        .card {
            background: var(--bg2);
            border: 1px solid var(--bor);
            border-radius: 14px;
            padding: 16px;
        }
        .card-gold {
            background: rgba(232,184,32,.04);
            border-color: var(--bor2);
        }

        /* ─── KPI Grid ─── */
        .kpi-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(180px, 1fr));
            gap: 12px;
            margin-bottom: 20px;
        }
        .kpi-card {
            text-align: center;
            padding: 18px 14px;
        }
        .kpi-card .icon { font-size: 28px; margin-bottom: 4px; }
        .kpi-card .value { font-size: 32px; font-weight: 900; margin: 4px 0; }
        .kpi-card .label { font-size: 12px; color: var(--mut); }

        /* ─── Table ─── */
        .data-table { width: 100%; border-collapse: collapse; }
        .data-table th {
            text-align: left;
            font-size: 11px;
            font-weight: 700;
            color: var(--mut);
            text-transform: uppercase;
            padding: 10px 14px;
            border-bottom: 1px solid var(--bor);
        }
        .data-table td {
            padding: 12px 14px;
            font-size: 13px;
            border-bottom: 1px solid var(--bor);
            vertical-align: middle;
        }
        .data-table tr:hover td { background: rgba(255,255,255,.02); }

        /* ─── Buttons ─── */
        .btn {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 7px 16px;
            border-radius: 10px;
            border: 1px solid var(--bor);
            cursor: pointer;
            font-family: 'Kanit', sans-serif;
            font-size: 12px;
            font-weight: 700;
            transition: all .15s;
        }
        .btn-gold {
            background: linear-gradient(135deg, var(--gold4), var(--gold));
            color: #3d1f00;
            border-color: var(--gold4);
        }
        .btn-gold:hover { filter: brightness(1.1); }
        .btn-green {
            background: rgba(63,185,80,.12);
            color: var(--grn);
            border-color: rgba(63,185,80,.3);
        }
        .btn-green:hover { background: rgba(63,185,80,.2); }
        .btn-red {
            background: rgba(248,81,73,.1);
            color: var(--err);
            border-color: rgba(248,81,73,.25);
        }
        .btn-red:hover { background: rgba(248,81,73,.18); }
        .btn-secondary {
            background: rgba(255,255,255,.04);
            color: var(--sub);
        }
        .btn-secondary:hover { background: rgba(255,255,255,.08); }

        /* ─── Filters ─── */
        .filter-bar { display: flex; gap: 6px; margin-bottom: 16px; flex-wrap: wrap; }
        .filter-btn {
            padding: 5px 16px;
            border-radius: 20px;
            border: none;
            cursor: pointer;
            font-family: 'Kanit', sans-serif;
            font-size: 11px;
            font-weight: 700;
            background: rgba(255,255,255,.04);
            color: var(--mut);
            transition: all .15s;
        }
        .filter-btn.active {
            background: rgba(232,184,32,.12);
            color: var(--gold);
            outline: 1px solid var(--gold4);
        }

        /* ─── Badges ─── */
        .badge {
            display: inline-block;
            font-size: 10px;
            font-weight: 800;
            padding: 2px 8px;
            border-radius: 6px;
            border: 1px solid;
        }
        .badge-green  { background: rgba(63,185,80,.1);  color: var(--grn); border-color: rgba(63,185,80,.3); }
        .badge-yellow { background: rgba(232,184,32,.1);  color: var(--gold); border-color: rgba(232,184,32,.3); }
        .badge-red    { background: rgba(248,81,73,.08);  color: var(--err); border-color: rgba(248,81,73,.2); }

        /* ─── Forms ─── */
        .form-input {
            width: 100%;
            padding: 10px 14px;
            border-radius: 12px;
            border: 1px solid var(--bor);
            background: rgba(255,255,255,.04);
            color: var(--txt);
            font-size: 13px;
            font-family: 'Kanit', sans-serif;
            outline: none;
            transition: border-color .2s;
        }
        .form-input:focus { border-color: var(--gold3); }
        .form-label {
            display: block;
            font-size: 11px;
            font-weight: 700;
            color: var(--mut);
            margin-bottom: 5px;
        }

        /* ─── Alert ─── */
        .alert {
            padding: 10px 14px;
            border-radius: 10px;
            font-size: 13px;
            font-weight: 700;
            margin-bottom: 12px;
        }
        .alert-success { background: rgba(63,185,80,.1); border: 1px solid rgba(63,185,80,.3); color: var(--grn); }
        .alert-error   { background: rgba(248,81,73,.1); border: 1px solid rgba(248,81,73,.3); color: var(--err); }

        /* ─── Image thumb ─── */
        .thumb {
            width: 64px; height: 64px;
            border-radius: 10px;
            object-fit: cover;
            border: 1px solid var(--bor);
            flex-shrink: 0;
        }

        /* ─── Mobile ─── */
        @media (max-width: 768px) {
            .sidebar { display: none; }
            .mobile-nav {
                display: flex !important;
                position: fixed;
                bottom: 0; left: 0; right: 0;
                background: var(--bg2);
                border-top: 1px solid var(--bor);
                z-index: 100;
                padding: 4px 0;
            }
            .mobile-nav a {
                flex: 1;
                display: flex;
                flex-direction: column;
                align-items: center;
                gap: 2px;
                padding: 6px 0;
                font-size: 9px;
                font-weight: 700;
                color: var(--mut);
                text-decoration: none;
                position: relative;
            }
            .mobile-nav a.active { color: var(--gold); }
            .mobile-nav a .m-emoji { font-size: 18px; }
            .mobile-nav a .m-badge {
                position: absolute;
                top: 2px; right: calc(50% - 18px);
                background: var(--err);
                color: #fff;
                font-size: 8px;
                padding: 0 4px;
                border-radius: 8px;
                min-width: 14px;
                text-align: center;
            }
            .main-content { padding: 16px 12px 80px; }
        }
        .mobile-nav { display: none; }

        /* ─── Empty state ─── */
        .empty-state {
            text-align: center;
            padding: 40px 20px;
            color: var(--mut);
            font-size: 14px;
        }
    </style>
</head>
<body>

<div class="admin-wrap">
    <!-- Sidebar (Desktop) -->
    <nav class="sidebar">
        <div class="sidebar-logo">
            <h1>⚙️ Admin Panel</h1>
            <p>เฮงเฮง ปังจัง Lucky Draw</p>
        </div>

        <a href="dashboard.php" class="nav-item <?= $currentPage === 'dashboard' ? 'active' : '' ?>">
            <span class="emoji">📊</span> ภาพรวม
        </a>
        <a href="receipts.php" class="nav-item <?= $currentPage === 'receipts' ? 'active' : '' ?>">
            <span class="emoji">📋</span> ใบเสร็จ
            <?php if ($pendingReceipts > 0): ?>
                <span class="nav-badge"><?= $pendingReceipts ?></span>
            <?php endif; ?>
        </a>
        <a href="merchants.php" class="nav-item <?= $currentPage === 'merchants' ? 'active' : '' ?>">
            <span class="emoji">🏪</span> ร้านค้า
            <?php if ($pendingMerchants > 0): ?>
                <span class="nav-badge"><?= $pendingMerchants ?></span>
            <?php endif; ?>
        </a>
        <a href="tickets.php" class="nav-item <?= $currentPage === 'tickets' ? 'active' : '' ?>">
            <span class="emoji">🎫</span> ฉลาก
        </a>
        <a href="banners.php" class="nav-item <?= $currentPage === 'banners' ? 'active' : '' ?>">
            <span class="emoji">🖼️</span> แบนเนอร์
        </a>
        <a href="config.php" class="nav-item <?= $currentPage === 'config' ? 'active' : '' ?>">
            <span class="emoji">⚙️</span> ตั้งค่า
        </a>

        <div class="sidebar-footer">
            <a href="logout.php">🚪 ออกจากระบบ</a>
        </div>
    </nav>

    <!-- Main -->
    <main class="main-content">
