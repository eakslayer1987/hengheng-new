<?php
require_once __DIR__ . '/../../includes/db.php';
require_once __DIR__ . '/../../includes/auth.php';
require_once __DIR__ . '/../../includes/functions.php';
apiCorsHeaders();
requireApiToken();

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $status = $_GET['status'] ?? 'pending';
    $limit  = min(100, max(1, (int)($_GET['limit'] ?? 30)));
    $where  = $status !== 'all' ? "WHERE r.status = ?" : "";
    $params = $status !== 'all' ? [$status] : [];

    $receipts = db_all("
        SELECT r.*, m.name as merchantName, m.ownerName, m.phone as merchantPhone
        FROM Receipt r
        LEFT JOIN Merchant m ON r.merchantId = m.id
        {$where}
        ORDER BY r.submittedAt DESC
        LIMIT {$limit}
    ", $params);
    jsonResponse(['receipts' => $receipts]);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $body   = getJsonBody();
    $id     = (int)($body['id'] ?? 0);
    $action = $body['action'] ?? '';
    if (!$id || !in_array($action, ['approve', 'reject'])) jsonResponse(['error' => 'Invalid params'], 400);

    $newStatus = $action === 'approve' ? 'approved' : 'rejected';
    db_run("UPDATE Receipt SET status = ?, reviewedAt = NOW() WHERE id = ?", [$newStatus, $id]);

    if ($action === 'approve') {
        $receipt = db_one("SELECT * FROM Receipt WHERE id = ?", [$id]);
        if ($receipt) {
            $ticketsPerBag = (int)(db_one("SELECT `value` FROM SystemConfig WHERE `key`='tickets_per_bag'")['value'] ?? 30);
            $totalCodes = $receipt['bagCount'] * $ticketsPerBag;
            $existing = db_one("SELECT id FROM MerchantQuota WHERE merchantId = ?", [$receipt['merchantId']]);
            if ($existing) {
                db_run("UPDATE MerchantQuota SET totalCodes = totalCodes + ? WHERE merchantId = ?", [$totalCodes, $receipt['merchantId']]);
            } else {
                db_run("INSERT INTO MerchantQuota (merchantId, campaignId, totalCodes, usedCodes, createdAt) VALUES (?, 1, ?, 0, NOW())", [$receipt['merchantId'], $totalCodes]);
            }
        }
    }
    jsonResponse(['ok' => true, 'status' => $newStatus]);
}
jsonResponse(['error' => 'Method not allowed'], 405);
