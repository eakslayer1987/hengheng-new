<?php
/**
 * admin/api/tickets.php — Digital Tickets API
 * GET ?status=activated&isWinner=1&limit=50 → { tickets: [...] }
 */
require_once __DIR__ . '/../../includes/db.php';
require_once __DIR__ . '/../../includes/auth.php';
require_once __DIR__ . '/../../includes/functions.php';

apiCorsHeaders();
requireApiToken();

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $limit    = min(200, max(1, (int)($_GET['limit'] ?? 50)));
    $where    = "WHERE 1=1";
    $params   = [];

    if (isset($_GET['status']) && $_GET['status'] !== 'all') {
        $where .= " AND dt.status = ?";
        $params[] = $_GET['status'];
    }

    if (isset($_GET['isWinner']) && $_GET['isWinner'] === '1') {
        $where .= " AND dt.isWinner = 1";
    }

    $tickets = db_all("
        SELECT dt.*, m.name as merchantName
        FROM DigitalTicket dt
        LEFT JOIN Merchant m ON dt.merchantId = m.id
        {$where}
        ORDER BY dt.createdAt DESC
        LIMIT {$limit}
    ", $params);

    jsonResponse(['tickets' => $tickets]);
}

jsonResponse(['error' => 'Method not allowed'], 405);
