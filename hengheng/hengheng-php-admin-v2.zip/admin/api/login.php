<?php
/**
 * admin/api/login.php — Login API (for Next.js admin)
 * POST { username, password } → { token, admin }
 */
require_once __DIR__ . '/../../includes/db.php';
require_once __DIR__ . '/../../includes/auth.php';
require_once __DIR__ . '/../../includes/functions.php';

apiCorsHeaders();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(['error' => 'Method not allowed'], 405);
}

$body = getJsonBody();
$username = trim($body['username'] ?? '');
$password = $body['password'] ?? '';

if (!$username || !$password) {
    jsonResponse(['error' => 'กรุณากรอกข้อมูลให้ครบ'], 400);
}

$admin = verifyAdmin($username, $password);
if (!$admin) {
    jsonResponse(['error' => 'ชื่อผู้ใช้หรือรหัสผ่านไม่ถูกต้อง'], 401);
}

$token = generateAdminToken($admin['id']);

jsonResponse([
    'token' => $token,
    'admin' => [
        'id'       => $admin['id'],
        'username' => $admin['username'],
    ],
]);
