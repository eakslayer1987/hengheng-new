<?php
require_once __DIR__ . '/../../includes/db.php';
require_once __DIR__ . '/../../includes/auth.php';
require_once __DIR__ . '/../../includes/functions.php';
apiCorsHeaders();
requireApiToken();

jsonResponse([
    'totalMerchants'   => (int)(db_one("SELECT COUNT(*) as c FROM Merchant")['c'] ?? 0),
    'pendingMerchants' => (int)(db_one("SELECT COUNT(*) as c FROM Merchant WHERE status='pending'")['c'] ?? 0),
    'pendingReceipts'  => (int)(db_one("SELECT COUNT(*) as c FROM Receipt WHERE status='pending'")['c'] ?? 0),
    'todayScans'       => (int)(db_one("SELECT COUNT(*) as c FROM DigitalTicket WHERE DATE(createdAt) = CURDATE()")['c'] ?? 0),
    'totalTickets'     => (int)(db_one("SELECT COUNT(*) as c FROM DigitalTicket")['c'] ?? 0),
    'totalWinners'     => (int)(db_one("SELECT COUNT(*) as c FROM DigitalTicket WHERE isWinner = 1")['c'] ?? 0),
]);
