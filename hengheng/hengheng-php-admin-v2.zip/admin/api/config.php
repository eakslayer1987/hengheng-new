<?php
/**
 * admin/api/config.php — System Config API
 * GET  → { config: { key: value, ... } }
 * POST { key: value, ... } → { ok }
 */
require_once __DIR__ . '/../../includes/db.php';
require_once __DIR__ . '/../../includes/auth.php';
require_once __DIR__ . '/../../includes/functions.php';

apiCorsHeaders();
requireApiToken();

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $rows = db_all("SELECT `key`, `value` FROM SystemConfig");
    $config = [];
    foreach ($rows as $r) {
        $config[$r['key']] = $r['value'];
    }
    jsonResponse(['config' => $config]);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $body = getJsonBody();

    foreach ($body as $key => $value) {
        if (!is_string($key) || $key === '') continue;
        $value = (string)$value;

        $existing = db_one("SELECT id FROM SystemConfig WHERE `key` = ?", [$key]);
        if ($existing) {
            db_run("UPDATE SystemConfig SET `value` = ?, updatedAt = NOW() WHERE `key` = ?", [$value, $key]);
        } else {
            db_run("INSERT INTO SystemConfig (`key`, `value`, createdAt, updatedAt) VALUES (?, ?, NOW(), NOW())", [$key, $value]);
        }
    }

    jsonResponse(['ok' => true]);
}

jsonResponse(['error' => 'Method not allowed'], 405);
