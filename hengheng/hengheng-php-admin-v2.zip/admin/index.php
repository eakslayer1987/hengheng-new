<?php
/**
 * admin/index.php — Login Page
 * เฮงเฮง ปังจัง Admin
 */
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';

// Already logged in → go to dashboard
if (isAdminLoggedIn()) {
    header('Location: dashboard.php');
    exit;
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    $admin = verifyAdmin($username, $password);
    if ($admin) {
        $_SESSION['admin_id']   = $admin['id'];
        $_SESSION['admin_user'] = $admin['username'];
        header('Location: dashboard.php');
        exit;
    } else {
        $error = 'ชื่อผู้ใช้หรือรหัสผ่านไม่ถูกต้อง';
    }
}
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>เข้าสู่ระบบ — เฮงเฮง ปังจัง Admin</title>
    <link href="https://fonts.googleapis.com/css2?family=Kanit:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    <style>
        * { margin:0; padding:0; box-sizing:border-box; }
        body {
            font-family: 'Kanit', sans-serif;
            background: #0d1117;
            color: #e6edf3;
            min-height: 100dvh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 24px;
        }
        .login-box {
            width: 100%;
            max-width: 380px;
        }
        .login-header {
            text-align: center;
            margin-bottom: 28px;
        }
        .login-header .icon { font-size: 52px; margin-bottom: 8px; }
        .login-header h1 {
            font-size: 26px;
            font-weight: 900;
        }
        .login-header h1 span {
            background: linear-gradient(135deg, #F5D78E, #A67208);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        .login-header p { font-size: 13px; color: rgba(150,170,210,.4); margin-top: 4px; }

        .login-card {
            background: #161b22;
            border: 1px solid rgba(255,255,255,.08);
            border-radius: 16px;
            padding: 24px;
        }
        .form-group { margin-bottom: 16px; }
        .form-group label {
            display: block;
            font-size: 11px;
            font-weight: 700;
            color: rgba(150,170,210,.4);
            margin-bottom: 6px;
        }
        .form-group input {
            width: 100%;
            padding: 12px 14px;
            border-radius: 12px;
            border: 1px solid rgba(255,255,255,.08);
            background: rgba(255,255,255,.04);
            color: #e6edf3;
            font-size: 14px;
            font-family: 'Kanit', sans-serif;
            outline: none;
            transition: border-color .2s;
        }
        .form-group input:focus { border-color: #C9963A; }

        .error-msg {
            padding: 8px 12px;
            border-radius: 10px;
            font-size: 12px;
            font-weight: 700;
            background: rgba(248,81,73,.1);
            border: 1px solid rgba(248,81,73,.3);
            color: #f85149;
            margin-bottom: 16px;
        }

        .btn-login {
            width: 100%;
            height: 48px;
            border: none;
            border-radius: 14px;
            cursor: pointer;
            font-family: 'Kanit', sans-serif;
            font-size: 15px;
            font-weight: 800;
            background: linear-gradient(135deg, #A67208, #E8B820);
            color: #3d1f00;
            transition: filter .15s;
        }
        .btn-login:hover { filter: brightness(1.1); }
    </style>
</head>
<body>

<div class="login-box">
    <div class="login-header">
        <div class="icon">⚙️</div>
        <h1>Admin <span>Panel</span></h1>
        <p>เฮงเฮง ปังจัง Lucky Draw</p>
    </div>

    <div class="login-card">
        <?php if ($error): ?>
            <div class="error-msg">⚠️ <?= e($error) ?></div>
        <?php endif; ?>

        <form method="POST" action="">
            <div class="form-group">
                <label>Username</label>
                <input type="text" name="username" placeholder="admin" required autofocus
                       value="<?= e($_POST['username'] ?? '') ?>">
            </div>
            <div class="form-group">
                <label>Password</label>
                <input type="password" name="password" placeholder="••••••••" required>
            </div>
            <button type="submit" class="btn-login">🔐 เข้าสู่ระบบ</button>
        </form>
    </div>
</div>

</body>
</html>
