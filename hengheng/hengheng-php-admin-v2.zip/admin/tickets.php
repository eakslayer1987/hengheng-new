<?php
/**
 * admin/tickets.php — ฉลากดิจิทัล
 * Fixed: DigitalTicket status = unclaimed/activated, activatedAt
 */
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
requireAdminLogin();

$msg = '';
$msgType = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $code   = trim($_POST['code'] ?? '');
    $action = $_POST['action'] ?? '';
    if ($code && $action === 'set_winner') {
        $affected = db_run("UPDATE DigitalTicket SET isWinner = 1 WHERE ticketCode = ?", [$code]);
        if ($affected) {
            $msg = "🏆 ตั้ง {$code} เป็นผู้โชคดี!";
            $msgType = 'success';
        }
    }
}

$search = trim($_GET['q'] ?? '');
$where  = "WHERE 1=1";
$params = [];
if ($search) {
    $where .= " AND (dt.ticketCode LIKE ? OR dt.customerPhone LIKE ? OR dt.customerName LIKE ?)";
    $like = "%{$search}%";
    $params = array_merge($params, [$like, $like, $like]);
}

$winners = db_all("
    SELECT dt.*, m.name as merchantName
    FROM DigitalTicket dt
    LEFT JOIN Merchant m ON dt.merchantId = m.id
    WHERE dt.isWinner = 1
    ORDER BY dt.createdAt DESC
    LIMIT 20
");

$tickets = db_all("
    SELECT dt.*, m.name as merchantName
    FROM DigitalTicket dt
    LEFT JOIN Merchant m ON dt.merchantId = m.id
    {$where}
    ORDER BY dt.createdAt DESC
    LIMIT 100
", $params);

require_once __DIR__ . '/layout.php';
?>

<div class="page-header">
    <h2>🎫 ฉลาก<span>ดิจิทัล</span></h2>
    <span style="font-size:12px;color:var(--mut)">ทั้งหมด <?= fmt(count($tickets)) ?> รายการ</span>
</div>

<?php if ($msg): ?>
    <div class="alert alert-<?= $msgType ?>"><?= $msg ?></div>
<?php endif; ?>

<?php if (!empty($winners)): ?>
<div class="card card-gold" style="margin-bottom:16px">
    <h3 style="font-size:14px;font-weight:800;color:var(--gold);margin-bottom:10px">🏆 ผู้โชคดี <?= count($winners) ?> ราย</h3>
    <table class="data-table">
        <thead><tr><th>โค้ด</th><th>ลูกค้า</th><th>ร้านค้า</th><th>วันที่</th></tr></thead>
        <tbody>
            <?php foreach ($winners as $w): ?>
            <tr>
                <td><span style="font-family:monospace;font-weight:900;letter-spacing:2px;color:var(--gold)"><?= e($w['ticketCode']) ?></span> 🏆</td>
                <td><?= e($w['customerName'] ?? '-') ?><br><span style="font-size:11px;color:var(--mut)"><?= e($w['customerPhone'] ?? '') ?></span></td>
                <td style="color:var(--sub)"><?= e($w['merchantName'] ?? '-') ?></td>
                <td style="font-size:11px;color:var(--mut)"><?= thaiDateShort($w['createdAt']) ?></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
<?php endif; ?>

<form method="GET" style="margin-bottom:16px">
    <div style="display:flex;gap:8px">
        <input type="text" name="q" value="<?= e($search) ?>" placeholder="🔍 ค้นหาโค้ด หรือเบอร์โทร" class="form-input" style="flex:1">
        <button type="submit" class="btn btn-gold">ค้นหา</button>
    </div>
</form>

<div class="card">
    <?php if (empty($tickets)): ?>
        <div class="empty-state">ไม่พบรายการ</div>
    <?php else: ?>
        <table class="data-table">
            <thead><tr><th>โค้ด</th><th>ลูกค้า</th><th>ร้านค้า</th><th>สถานะ</th><th>วันที่</th><th></th></tr></thead>
            <tbody>
                <?php foreach ($tickets as $t): ?>
                <tr>
                    <td>
                        <span style="font-family:monospace;font-weight:800;letter-spacing:2px;color:<?= $t['isWinner'] ? 'var(--gold)' : 'var(--txt)' ?>">
                            <?= e($t['ticketCode']) ?>
                        </span>
                        <?php if ($t['isWinner']): ?><span style="margin-left:4px;font-size:10px">🏆</span><?php endif; ?>
                    </td>
                    <td>👤 <?= e($t['customerName'] ?? '-') ?><br><span style="font-size:11px;color:var(--mut)"><?= e($t['customerPhone'] ?? '') ?></span></td>
                    <td style="font-size:12px;color:var(--sub)">🏪 <?= e($t['merchantName'] ?? '-') ?></td>
                    <td>
                        <?php
                            $st = $t['status'] ?? 'unclaimed';
                            $bC = $st === 'activated' ? 'badge-green' : 'badge-yellow';
                            $bT = $st === 'activated' ? '✅ สแกนแล้ว' : '⏳ รอสแกน';
                        ?>
                        <span class="badge <?= $bC ?>"><?= $bT ?></span>
                    </td>
                    <td style="font-size:11px;color:var(--mut)"><?= thaiDate($t['createdAt']) ?></td>
                    <td>
                        <?php if (!$t['isWinner'] && $st === 'activated'): ?>
                        <form method="POST" style="display:inline">
                            <input type="hidden" name="code" value="<?= e($t['ticketCode']) ?>">
                            <input type="hidden" name="action" value="set_winner">
                            <button type="submit" class="btn btn-gold" style="font-size:10px;padding:4px 10px"
                                    onclick="return confirm('ตั้ง <?= e($t['ticketCode']) ?> เป็นผู้โชคดี?')">🏆 ตั้งผู้โชคดี</button>
                        </form>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
</div>

<?php require_once __DIR__ . '/layout_footer.php'; ?>
