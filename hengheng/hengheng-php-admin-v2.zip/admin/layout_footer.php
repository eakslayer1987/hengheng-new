    </main>
</div>

<!-- Mobile Bottom Nav -->
<nav class="mobile-nav">
    <a href="dashboard.php" class="<?= $currentPage === 'dashboard' ? 'active' : '' ?>">
        <span class="m-emoji">📊</span> ภาพรวม
    </a>
    <a href="receipts.php" class="<?= $currentPage === 'receipts' ? 'active' : '' ?>">
        <span class="m-emoji">📋</span>
        <?php if ($pendingReceipts > 0): ?><span class="m-badge"><?= $pendingReceipts ?></span><?php endif; ?>
        ใบเสร็จ
    </a>
    <a href="merchants.php" class="<?= $currentPage === 'merchants' ? 'active' : '' ?>">
        <span class="m-emoji">🏪</span>
        <?php if ($pendingMerchants > 0): ?><span class="m-badge"><?= $pendingMerchants ?></span><?php endif; ?>
        ร้านค้า
    </a>
    <a href="tickets.php" class="<?= $currentPage === 'tickets' ? 'active' : '' ?>">
        <span class="m-emoji">🎫</span> ฉลาก
    </a>
    <a href="config.php" class="<?= $currentPage === 'config' ? 'active' : '' ?>">
        <span class="m-emoji">⚙️</span> ตั้งค่า
    </a>
</nav>

</body>
</html>
