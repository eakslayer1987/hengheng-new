<?php
/**
 * admin/banners.php — จัดการแบนเนอร์
 */
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
requireAdminLogin();

$msg = '';
$msgType = '';

$positions = [
    'user_topbar'    => 'แถบบนหน้าลูกค้า',
    'user_hero'      => 'Hero หน้าหลัก',
    'user_infeed'    => 'Card กลางหน้า',
    'user_popup'     => 'Popup modal',
    'user_sticky'    => 'Sticky bar ล่าง',
    'merchant_hero'  => 'Hero ร้านค้า',
    'merchant_card'  => 'Card ร้านค้า',
    'merchant_popup' => 'Popup ร้านค้า',
    'admin_alert'    => 'Alert Admin',
];

// ─── Handle Actions ─────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'create') {
        db_run("INSERT INTO Banner (type, title, body, imageUrl, bgColor, linkUrl, position, isActive, createdAt) VALUES (?,?,?,?,?,?,?,1,NOW())", [
            $_POST['type'] ?? 'announcement',
            $_POST['title'] ?? '',
            $_POST['body'] ?? '',
            $_POST['imageUrl'] ?? '',
            $_POST['bgColor'] ?? '',
            $_POST['linkUrl'] ?? '',
            $_POST['position'] ?? 'user_hero',
        ]);
        $msg = "✅ สร้างแบนเนอร์ใหม่แล้ว";
        $msgType = 'success';
    }

    if ($action === 'delete') {
        $id = (int)($_POST['id'] ?? 0);
        if ($id) {
            db_run("DELETE FROM Banner WHERE id = ?", [$id]);
            $msg = "🗑️ ลบแบนเนอร์ #{$id}";
            $msgType = 'success';
        }
    }

    if ($action === 'toggle') {
        $id = (int)($_POST['id'] ?? 0);
        if ($id) {
            db_run("UPDATE Banner SET isActive = NOT isActive WHERE id = ?", [$id]);
            $msg = "✅ สลับสถานะแบนเนอร์ #{$id}";
            $msgType = 'success';
        }
    }
}

$banners = db_all("SELECT * FROM Banner ORDER BY position, createdAt DESC");

require_once __DIR__ . '/layout.php';
?>

<div class="page-header">
    <h2>🖼️ แบน<span>เนอร์</span></h2>
    <span style="font-size:12px;color:var(--mut)">ทั้งหมด <?= count($banners) ?> รายการ</span>
</div>

<?php if ($msg): ?>
    <div class="alert alert-<?= $msgType ?>"><?= $msg ?></div>
<?php endif; ?>

<!-- Create Form -->
<div class="card" style="margin-bottom:20px">
    <h3 style="font-size:14px;font-weight:800;margin-bottom:14px">
        ➕ สร้าง<span style="color:var(--gold)">แบนเนอร์ใหม่</span>
    </h3>
    <form method="POST">
        <input type="hidden" name="action" value="create">
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px">
            <div>
                <label class="form-label">หัวข้อ</label>
                <input type="text" name="title" class="form-input" placeholder="ชื่อแบนเนอร์" required>
            </div>
            <div>
                <label class="form-label">ตำแหน่ง</label>
                <select name="position" class="form-input">
                    <?php foreach ($positions as $k => $v): ?>
                        <option value="<?= $k ?>"><?= $v ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div>
                <label class="form-label">ประเภท</label>
                <select name="type" class="form-input">
                    <option value="announcement">Announcement</option>
                    <option value="image">Image</option>
                    <option value="card">Card</option>
                    <option value="popup">Popup</option>
                    <option value="sticky">Sticky</option>
                </select>
            </div>
            <div>
                <label class="form-label">URL รูป</label>
                <input type="url" name="imageUrl" class="form-input" placeholder="https://...">
            </div>
            <div>
                <label class="form-label">ข้อความ</label>
                <input type="text" name="body" class="form-input" placeholder="รายละเอียด (ไม่บังคับ)">
            </div>
            <div>
                <label class="form-label">ลิงก์</label>
                <input type="url" name="linkUrl" class="form-input" placeholder="https://... (ไม่บังคับ)">
            </div>
            <div>
                <label class="form-label">สีพื้นหลัง</label>
                <input type="text" name="bgColor" class="form-input" placeholder="#E8B820">
            </div>
            <div style="display:flex;align-items:flex-end">
                <button type="submit" class="btn btn-gold" style="width:100%;height:42px;justify-content:center;font-size:13px">
                    💾 สร้างแบนเนอร์
                </button>
            </div>
        </div>
    </form>
</div>

<!-- Banners List -->
<?php if (empty($banners)): ?>
    <div class="empty-state">ยังไม่มีแบนเนอร์</div>
<?php else: ?>
    <div class="card">
        <table class="data-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>หัวข้อ</th>
                    <th>ตำแหน่ง</th>
                    <th>ประเภท</th>
                    <th>สถานะ</th>
                    <th>จัดการ</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($banners as $b): ?>
                <tr>
                    <td style="font-weight:800;color:var(--mut)">#<?= $b['id'] ?></td>
                    <td>
                        <span style="font-weight:700"><?= e($b['title']) ?></span>
                        <?php if ($b['body']): ?>
                            <br><span style="font-size:11px;color:var(--mut)"><?= e(mb_substr($b['body'], 0, 40)) ?></span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <span class="badge badge-yellow" style="font-size:9px">
                            <?= $positions[$b['position']] ?? $b['position'] ?>
                        </span>
                    </td>
                    <td style="font-size:12px;color:var(--sub)"><?= e($b['type']) ?></td>
                    <td>
                        <span class="badge <?= ($b['isActive'] ?? 1) ? 'badge-green' : 'badge-red' ?>">
                            <?= ($b['isActive'] ?? 1) ? '✅ เปิด' : '⏸️ ปิด' ?>
                        </span>
                    </td>
                    <td>
                        <div style="display:flex;gap:4px">
                            <form method="POST" style="display:inline">
                                <input type="hidden" name="id" value="<?= $b['id'] ?>">
                                <input type="hidden" name="action" value="toggle">
                                <button type="submit" class="btn btn-secondary" style="font-size:10px;padding:3px 8px">
                                    🔀 สลับ
                                </button>
                            </form>
                            <form method="POST" style="display:inline"
                                  onsubmit="return confirm('ลบแบนเนอร์นี้?')">
                                <input type="hidden" name="id" value="<?= $b['id'] ?>">
                                <input type="hidden" name="action" value="delete">
                                <button type="submit" class="btn btn-red" style="font-size:10px;padding:3px 8px">
                                    🗑️
                                </button>
                            </form>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
<?php endif; ?>

<?php require_once __DIR__ . '/layout_footer.php'; ?>
