<?php
/**
 * admin/config.php — ตั้งค่าระบบ
 */
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
requireAdminLogin();

$msg = '';
$msgType = '';

// ─── Config keys with labels ────────────
$CONFIG_KEYS = [
    'app_name'            => ['ชื่อแอป',                'text',   'เฮงเฮง ปังจัง'],
    'app_subtitle'        => ['คำโปรย',                 'text',   'สะสมแด้น ลุ้นโชคใหญ่!'],
    'daily_collect_limit' => ['สิทธิ์สะสม/วัน',          'number', '3'],
    'gps_radius_m'        => ['รัศมี GPS (เมตร)',        'number', '20'],
    'otp_expire_min'      => ['OTP หมดอายุ (นาที)',      'number', '5'],
    'tickets_per_bag'     => ['ฉลากต่อถุง',              'number', '30'],
    'registration_open'   => ['เปิดรับสมัคร',            'select', 'true'],
    'prize_total_value'   => ['มูลค่ารางวัลรวม (บาท)',    'number', '100000'],
    'campaign_name'       => ['ชื่อแคมเปญ',              'text',   'เฮงเฮง ปังจัง Lucky Draw 2026'],
    'campaign_end_date'   => ['วันสิ้นสุดแคมเปญ',        'date',   '2026-12-31'],
];

// ─── Save Config ─────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    foreach ($CONFIG_KEYS as $key => $_) {
        if (isset($_POST[$key])) {
            $value = trim($_POST[$key]);
            $existing = db_one("SELECT id FROM SystemConfig WHERE `key` = ?", [$key]);
            if ($existing) {
                db_run("UPDATE SystemConfig SET `value` = ?, updatedAt = NOW() WHERE `key` = ?", [$value, $key]);
            } else {
                db_run("INSERT INTO SystemConfig (`key`, `value`, createdAt, updatedAt) VALUES (?, ?, NOW(), NOW())", [$key, $value]);
            }
        }
    }
    $msg = '✅ บันทึกการตั้งค่าสำเร็จ';
    $msgType = 'success';
}

// ─── Load current config ─────────────────
$rows = db_all("SELECT `key`, `value` FROM SystemConfig");
$config = [];
foreach ($rows as $r) {
    $config[$r['key']] = $r['value'];
}

require_once __DIR__ . '/layout.php';
?>

<div class="page-header">
    <h2>⚙️ ตั้ง<span>ค่า</span>ระบบ</h2>
</div>

<?php if ($msg): ?>
    <div class="alert alert-<?= $msgType ?>"><?= $msg ?></div>
<?php endif; ?>

<form method="POST">
    <div class="card" style="margin-bottom:20px">
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px">
            <?php foreach ($CONFIG_KEYS as $key => [$label, $type, $default]): ?>
            <div>
                <label class="form-label"><?= $label ?></label>
                <?php if ($type === 'select'): ?>
                    <select name="<?= $key ?>" class="form-input">
                        <option value="true"  <?= ($config[$key] ?? $default) === 'true' ? 'selected' : '' ?>>เปิด (true)</option>
                        <option value="false" <?= ($config[$key] ?? $default) === 'false' ? 'selected' : '' ?>>ปิด (false)</option>
                    </select>
                <?php else: ?>
                    <input type="<?= $type ?>" name="<?= $key ?>"
                           value="<?= e($config[$key] ?? $default) ?>"
                           class="form-input">
                <?php endif; ?>
            </div>
            <?php endforeach; ?>
        </div>
    </div>

    <button type="submit" class="btn btn-gold" style="width:100%;height:48px;justify-content:center;font-size:14px;border-radius:14px">
        💾 บันทึกการตั้งค่า
    </button>
</form>

<!-- Database Info -->
<div class="card" style="margin-top:24px">
    <h3 style="font-size:14px;font-weight:800;margin-bottom:12px">
        🗄️ ข้อมูล<span style="color:var(--gold)">ฐานข้อมูล</span>
    </h3>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;font-size:12px">
        <?php
        $tables = ['AdminUser','Campaign','Merchant','Receipt','MerchantQuota','DigitalTicket','OtpCode','SystemConfig','Banner','QrRule','GalleryPhoto'];
        foreach ($tables as $t):
            $count = 0;
            try { $count = (int)(db_one("SELECT COUNT(*) as c FROM `{$t}`")['c'] ?? 0); } catch (Exception $e) {}
        ?>
        <div style="display:flex;justify-content:space-between;padding:6px 10px;border-radius:8px;background:rgba(255,255,255,.02)">
            <span style="color:var(--sub)"><?= $t ?></span>
            <span style="font-weight:800;color:var(--gold)"><?= fmt($count) ?></span>
        </div>
        <?php endforeach; ?>
    </div>
</div>

<?php require_once __DIR__ . '/layout_footer.php'; ?>
