<?php
/**
 * admin/dashboard.php — ภาพรวม KPI
 * Fixed to match actual DB schema
 */
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
requireAdminLogin();

// ─── KPI Queries ─────────────────────────
$totalMerchants   = (int)(db_one("SELECT COUNT(*) as c FROM Merchant")['c'] ?? 0);
$pendingMerch     = (int)(db_one("SELECT COUNT(*) as c FROM Merchant WHERE status='pending'")['c'] ?? 0);
$approvedMerch    = (int)(db_one("SELECT COUNT(*) as c FROM Merchant WHERE status='approved'")['c'] ?? 0);
$pendingReceipts  = (int)(db_one("SELECT COUNT(*) as c FROM Receipt WHERE status='pending'")['c'] ?? 0);
$totalReceipts    = (int)(db_one("SELECT COUNT(*) as c FROM Receipt")['c'] ?? 0);
$todayScans       = (int)(db_one("SELECT COUNT(*) as c FROM DigitalTicket WHERE DATE(createdAt) = CURDATE()")['c'] ?? 0);
$totalTickets     = (int)(db_one("SELECT COUNT(*) as c FROM DigitalTicket")['c'] ?? 0);
$totalWinners     = (int)(db_one("SELECT COUNT(*) as c FROM DigitalTicket WHERE isWinner = 1")['c'] ?? 0);
$totalBags        = (int)(db_one("SELECT COALESCE(SUM(bagCount),0) as c FROM Receipt WHERE status='approved'")['c'] ?? 0);

// ─── Recent activity (last 10) ───────────
$recentTickets = db_all("
    SELECT dt.ticketCode, dt.customerName, dt.createdAt, m.name as merchantName
    FROM DigitalTicket dt
    LEFT JOIN Merchant m ON dt.merchantId = m.id
    ORDER BY dt.createdAt DESC
    LIMIT 10
");

// ─── Weekly chart data (7 days) ──────────
$weekData = db_all("
    SELECT DATE(createdAt) as d, COUNT(*) as c
    FROM DigitalTicket
    WHERE createdAt >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)
    GROUP BY DATE(createdAt)
    ORDER BY d
");

require_once __DIR__ . '/layout.php';
?>

<div class="page-header">
    <h2>📊 ภาพรวม<span>ระบบ</span></h2>
    <span style="font-size:12px;color:var(--mut)">
        <?= date('j/m/Y H:i') ?> น.
    </span>
</div>

<div class="kpi-grid">
    <div class="card kpi-card">
        <div class="icon">🏪</div>
        <div class="value" style="color:var(--blue)"><?= fmt($totalMerchants) ?></div>
        <div class="label">ร้านค้าทั้งหมด</div>
    </div>
    <div class="card kpi-card">
        <div class="icon">✅</div>
        <div class="value" style="color:var(--grn)"><?= fmt($approvedMerch) ?></div>
        <div class="label">ร้านอนุมัติแล้ว</div>
    </div>
    <div class="card kpi-card">
        <div class="icon">⏳</div>
        <div class="value" style="color:var(--gold)"><?= fmt($pendingMerch + $pendingReceipts) ?></div>
        <div class="label">รอดำเนินการ</div>
    </div>
    <div class="card kpi-card">
        <div class="icon">📱</div>
        <div class="value" style="color:var(--grn)"><?= fmt($todayScans) ?></div>
        <div class="label">สแกนวันนี้</div>
    </div>
    <div class="card kpi-card">
        <div class="icon">🎫</div>
        <div class="value" style="color:var(--blue)"><?= fmt($totalTickets) ?></div>
        <div class="label">ฉลากทั้งหมด</div>
    </div>
    <div class="card kpi-card">
        <div class="icon">🏆</div>
        <div class="value" style="color:var(--gold)"><?= fmt($totalWinners) ?></div>
        <div class="label">ผู้โชคดี</div>
    </div>
    <div class="card kpi-card">
        <div class="icon">📋</div>
        <div class="value" style="color:var(--err)"><?= fmt($pendingReceipts) ?></div>
        <div class="label">ใบเสร็จรอ</div>
    </div>
    <div class="card kpi-card">
        <div class="icon">🛍️</div>
        <div class="value" style="color:var(--gold)"><?= fmt($totalBags) ?></div>
        <div class="label">ถุงรวม</div>
    </div>
</div>

<div class="card" style="margin-bottom:20px">
    <h3 style="font-size:15px;font-weight:800;margin-bottom:14px">
        📈 สแกน 7 วัน<span style="color:var(--gold)">ล่าสุด</span>
    </h3>
    <div style="display:flex;align-items:flex-end;gap:6px;height:120px;padding:0 8px">
        <?php
        $maxC = max(array_column($weekData, 'c') ?: [1]);
        $days = ['อา','จ','อ','พ','พฤ','ศ','ส'];
        foreach ($weekData as $wd):
            $pct = ($wd['c'] / $maxC) * 100;
            $dow = $days[(int)date('w', strtotime($wd['d']))];
        ?>
        <div style="flex:1;display:flex;flex-direction:column;align-items:center;gap:4px">
            <span style="font-size:11px;font-weight:800;color:var(--gold)"><?= $wd['c'] ?></span>
            <div style="width:100%;border-radius:6px 6px 0 0;
                        background:linear-gradient(180deg,var(--gold),var(--gold4));
                        height:<?= max(4, $pct) ?>%"></div>
            <span style="font-size:10px;color:var(--mut)"><?= $dow ?></span>
        </div>
        <?php endforeach; ?>
        <?php if (empty($weekData)): ?>
            <div style="width:100%;text-align:center;color:var(--mut);font-size:12px;padding:40px 0">
                ยังไม่มีข้อมูล
            </div>
        <?php endif; ?>
    </div>
</div>

<div class="card">
    <h3 style="font-size:15px;font-weight:800;margin-bottom:14px">
        ⚡ กิจกรรม<span style="color:var(--gold)">ล่าสุด</span>
    </h3>
    <?php if (empty($recentTickets)): ?>
        <div class="empty-state">ยังไม่มีกิจกรรม</div>
    <?php else: ?>
        <table class="data-table">
            <thead><tr><th>โค้ด</th><th>ลูกค้า</th><th>ร้านค้า</th><th>เวลา</th></tr></thead>
            <tbody>
                <?php foreach ($recentTickets as $t): ?>
                <tr>
                    <td><span style="font-family:monospace;font-weight:800;letter-spacing:2px;color:var(--gold)"><?= e($t['ticketCode']) ?></span></td>
                    <td><?= e($t['customerName'] ?? '-') ?></td>
                    <td style="color:var(--sub)"><?= e($t['merchantName'] ?? '-') ?></td>
                    <td style="font-size:11px;color:var(--mut)"><?= thaiDate($t['createdAt']) ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
</div>

<?php require_once __DIR__ . '/layout_footer.php'; ?>
