# 🚀 เฮงเฮง ปังจัง — Deployment Guide
## สรุปการแก้ไขทั้งหมด

---

## 1️⃣ LINE Login Flow Fix (Vercel Security Checkpoint)

### ปัญหา
LINE callback redirect ไป `NEXT_PUBLIC_APP_URL/home` ซึ่งเป็น external URL → Vercel เห็นเป็น cross-origin redirect → แสดง Security Checkpoint

### วิธีแก้
ไฟล์: `src/app/api/auth/line-callback/route.ts`
- ใช้ `req.nextUrl.clone()` แทน `NEXT_PUBLIC_APP_URL` สำหรับ redirect
- เป็น same-origin redirect → Vercel ไม่ block

### ขั้นตอน Deploy
```
แทนที่ไฟล์: src/app/api/auth/line-callback/route.ts
```

### ⚠️ ตรวจสอบ Vercel Environment Variables
```
LINE_CHANNEL_ID=2009570975
LINE_CHANNEL_SECRET=<secret>
LINE_CALLBACK_URL=https://xn--72ca9ib1gc.xn--72cac8e8ec.com/api/auth/line-callback
JWT_SECRET=<your-secret-key>
NEXT_PUBLIC_APP_URL=https://xn--72ca9ib1gc.xn--72cac8e8ec.com
NEXT_PUBLIC_PHP_API_URL=https://xn--72ca9ib1gc.xn--72cac8e8ec.com/hengheng/api
```

### ⚠️ LINE Developers Console
- Callback URL ต้องเป็น: `https://xn--72ca9ib1gc.xn--72cac8e8ec.com/api/auth/line-callback`
- Channel status ต้องเป็น "Published" (ไม่ใช่ "Developing")

---

## 2️⃣ รีดีไซน์ธีมหน้าหลักตรงโปสเตอร์

### ไฟล์ที่แก้
- `src/app/page.tsx` — Login page (ลูกค้าเฮง ร้านค้าเฮ หมีปรุงเปย์, มูลค่า 2.4M, เฮง/เฮ/เปย์ 3 เสา)
- `src/app/home/page.tsx` — Home page (hero + stat pills + เฮงเฮเปย์ section + banner carousel + live feed)
- `src/app/rewards/page.tsx` — Rewards page (รางวัลตรง poster: ทองคำ 10บาท/5บาท/1บาท/1สลึง + หมีปรุงเปย์ + คูปอง + Lucky Ticket)
- `src/styles/globals.css` — CSS animations (glowPulse, shimmer, etc.)

### Design System ตาม Poster
- สีหลัก: `#C41E3A` (แดงสด), `#8B001A` (แดงเข้ม), `#3D0008` (แดงดำ)
- สีทอง: `#FBF0C8` → `#F7D37A` → `#C9963A` (gradient)
- Pattern: Chinese damask (SVG) overlay
- Font: Kanit (ทุก weight)

---

## 3️⃣ BottomNav Fix

### ปัญหา
`/scan` ไม่มี BottomNav

### วิธีแก้
ไฟล์: `src/app/scan/page.tsx`
- เพิ่ม `import BottomNav` + `<BottomNav active="scan" />`
- เพิ่ม `pb-24` ที่ content area

### สถานะ BottomNav ทุกหน้า
| หน้า | BottomNav | สถานะ |
|------|-----------|--------|
| `/` (login) | ❌ ไม่ต้อง | ✅ |
| `/home` | ✅ | ✅ |
| `/rewards` | ✅ | ✅ |
| `/scan` | ✅ | ✅ แก้แล้ว |
| `/map` | ✅ | ✅ |
| `/me` | ✅ | ✅ |
| `/merchant` | ❌ portal แยก | ✅ |
| `/admin` | ❌ admin แยก | ✅ |

---

## 4️⃣ Campaign + รางวัล SQL

### ไฟล์
`sql/001_campaign_setup.sql`

### รัน SQL บน VPS
```bash
ssh root@203.170.192.192
mysql -u admin_xnca -p admin_xnca_fooddash < 001_campaign_setup.sql
```

### สร้าง Tables
- `campaigns` — แคมเปญ
- `prizes` — รางวัล (FK → campaigns)
- `banners` — แบนเนอร์ (9 ตำแหน่ง)
- `users` — ผู้ใช้ LINE
- `merchants` — ร้านค้า
- `digital_tickets` — ฉลากดิจิทัล
- `scan_logs` — ประวัติสแกน
- `receipts` — ใบเสร็จ
- `lucky_draw_results` — ผลจับรางวัล

### Seed Data ตรง Poster
- Campaign: "ลูกค้าเฮง ร้านค้าเฮ หมีปรุงเปย์" (active, 2,400,000 บาท)
- 8 ระดับรางวัล (ทอง 10 บาท → Lucky Ticket)
- 4 banners สำหรับ user_hero carousel

---

## 5️⃣ PHP API Fixes

### ไฟล์ (อัปโหลดไป VPS)
```
php-api/config.php      → /hengheng/config.php
php-api/campaign.php    → /hengheng/api/campaign.php
php-api/feed.php        → /hengheng/api/feed.php
php-api/banners.php     → /hengheng/api/banners.php
```

### Upload ไป VPS
```bash
scp php-api/*.php root@203.170.192.192:/home/xnca/domains/xn--72ca9ib1gc.xn--72cac8e8ec.com/public_html/hengheng/api/
scp php-api/config.php root@203.170.192.192:/home/xnca/domains/xn--72ca9ib1gc.xn--72cac8e8ec.com/public_html/hengheng/
```

### ⚠️ แก้ config.php ก่อน deploy
```php
define('DB_USER', 'admin_xnca');  // ตรวจสอบ username จริง
define('DB_PASS', '');             // ใส่ password จริง
```

### แก้ไข
- `campaign.php` — 500 error → ตอนนี้ fallback mock data ถ้ายังไม่มี DB
- `feed.php` — 500 error → ตอนนี้ fallback mock data ถ้ายังไม่มี scan_logs
- `banners.php` — 404 → สร้างไฟล์ใหม่ + fallback banners

---

## 📋 ลำดับ Deploy ที่แนะนำ

```
1. อัปโหลด config.php (แก้ DB password ก่อน!)
2. รัน SQL บน VPS
3. อัปโหลด PHP APIs (campaign.php, feed.php, banners.php)
4. ทดสอบ: curl https://xn--72ca9ib1gc.xn--72cac8e8ec.com/hengheng/api/campaign.php
5. แทนที่ไฟล์ Next.js ทั้งหมดใน src/
6. git push → Vercel auto-deploy
7. ทดสอบ LINE Login flow ตั้งแต่ต้น
```

---

## 🔍 ทดสอบหลัง Deploy

- [ ] `GET /hengheng/api/campaign.php` → JSON campaign + prizes
- [ ] `GET /hengheng/api/feed.php?limit=5` → JSON feed items
- [ ] `GET /hengheng/api/banners.php?position=user_hero` → JSON banners
- [ ] เปิด เฮงเฮง.ปังจัง.com → หน้า Login สีแดงทอง
- [ ] กด LINE Login → redirect ไป LINE → กลับมา /home สำเร็จ
- [ ] /home แสดง campaign มูลค่า 2,400,000 บาท
- [ ] BottomNav ติดทุกหน้า (home, rewards, scan, map, me)
- [ ] /rewards แสดงรางวัล 8 ระดับ
