'use client'
/**
 * /app/page.tsx — Login Page (หน้าแรก)
 * Design: Red Gold Chinese Lucky Draw — ตาม Poster หมีปรุง
 * "ลูกค้าเฮง ร้านค้าเฮ หมีปรุงเปย์"
 */

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { motion, AnimatePresence } from 'framer-motion'
import { useUserStore } from '@/store'

export default function LoginPage() {
  const router  = useRouter()
  const lineId  = useUserStore(s => s.lineId)
  const setUser = useUserStore(s => s.setUser)
  const [checking, setChecking] = useState(true)
  const [error, setError] = useState('')

  // Check URL error params
  useEffect(() => {
    const params = new URLSearchParams(window.location.search)
    if (params.get('error')) {
      setError(params.get('error') === 'auth_failed'
        ? 'เข้าสู่ระบบไม่สำเร็จ กรุณาลองใหม่'
        : 'เกิดข้อผิดพลาด กรุณาลองใหม่')
      // Clear URL params
      window.history.replaceState({}, '', '/')
    }
  }, [])

  // Check if already logged in (via JWT cookie)
  useEffect(() => {
    if (lineId) {
      router.replace('/home')
      return
    }
    fetch('/api/auth/me')
      .then(r => r.json())
      .then(d => {
        if (d.user) {
          setUser({
            lineId: d.user.lineId,
            lineDisplayName: d.user.lineDisplayName,
            lineAvatarUrl: d.user.lineAvatarUrl,
          })
          router.replace('/home')
        } else {
          setChecking(false)
        }
      })
      .catch(() => setChecking(false))
  }, [lineId, setUser, router])

  const handleLineLogin = () => {
    window.location.href = '/api/auth/line'
  }

  if (checking) {
    return (
      <main className="flex items-center justify-center min-h-dvh bg-[#3D0008]">
        <div className="text-center">
          <div className="text-6xl mb-4 animate-glowPulse">🏆</div>
          <p className="text-[rgba(251,240,200,.5)] text-sm">กำลังตรวจสอบ...</p>
        </div>
      </main>
    )
  }

  return (
    <main className="relative flex flex-col items-center justify-center min-h-dvh overflow-hidden
                     bg-gradient-to-b from-[#C41E3A] via-[#8B001A] to-[#3D0008] px-5">

      {/* Chinese pattern overlay */}
      <div className="damask-bg absolute inset-0 pointer-events-none" />

      {/* Large radial gold burst — like the poster's light explosion */}
      <div className="pointer-events-none absolute top-[-10%] left-1/2 -translate-x-1/2
                      w-[140vw] h-[60vh]
                      bg-[radial-gradient(ellipse_at_center,rgba(247,211,122,.25)_0%,rgba(201,150,58,.08)_40%,transparent_70%)]" />

      {/* Sparkle particles */}
      {Array.from({ length: 8 }).map((_, i) => (
        <motion.span
          key={i}
          className="pointer-events-none absolute text-xl"
          initial={{ opacity: 0 }}
          animate={{
            opacity: [0, 1, 0],
            y: [0, -20, 0],
            scale: [0.5, 1.2, 0.5],
          }}
          transition={{
            duration: 2 + i * 0.3,
            repeat: Infinity,
            delay: i * 0.4,
          }}
          style={{
            left: `${5 + i * 12}%`,
            top:  `${15 + (i % 4) * 8}%`,
          }}
        >
          {['✨','🪙','⭐','💫','🏅','🎖️','✨','🪙'][i]}
        </motion.span>
      ))}

      {/* Content card */}
      <motion.div
        initial={{ opacity: 0, y: 40, scale: 0.92 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
        className="relative w-full max-w-sm z-10"
      >
        {/* Brand badge */}
        <motion.div
          initial={{ opacity: 0, scale: 0.5 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.2, type: 'spring', stiffness: 200 }}
          className="flex justify-center mb-4"
        >
          <div className="relative">
            <div className="w-20 h-20 rounded-full
                           bg-gradient-to-br from-[#FBF0C8] via-[#F7D37A] to-[#C9963A]
                           flex items-center justify-center
                           shadow-[0_8px_32px_rgba(201,150,58,.5),0_0_0_3px_rgba(201,150,58,.2)]">
              <span className="text-4xl">🐻</span>
            </div>
            {/* Glow ring */}
            <div className="absolute inset-[-6px] rounded-full border border-[rgba(247,211,122,.3)]
                            animate-glowPulse" />
          </div>
        </motion.div>

        {/* Main card */}
        <div className="rounded-3xl overflow-hidden
                       bg-gradient-to-b from-[rgba(139,0,26,.95)] to-[rgba(61,0,8,.98)]
                       border border-[rgba(201,150,58,.3)]
                       shadow-[0_20px_60px_rgba(0,0,0,.6),0_0_60px_rgba(201,150,58,.1)]
                       backdrop-blur-sm">

          {/* Top gold line */}
          <div className="h-[2px] bg-gradient-to-r from-transparent via-[#F7D37A] to-transparent" />

          {/* Header section */}
          <div className="px-6 pt-6 pb-4 text-center">
            <h1 className="text-2xl font-black text-gold-gradient leading-tight tracking-wide">
              ลูกค้าเฮง ร้านค้าเฮ
            </h1>
            <h2 className="text-3xl font-black text-gold-gradient leading-tight mt-0.5">
              หมีปรุงเปย์
            </h2>
            <p className="text-sm text-[rgba(251,240,200,.65)] mt-2 font-medium">
              ลุ้นรวย แบบดับเบิ้ล
            </p>
          </div>

          {/* Prize badge — matching poster "รวมมูลค่า 2,400,000 บาท" */}
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.4, type: 'spring' }}
            className="flex justify-center px-6 pb-4"
          >
            <div className="relative inline-flex items-center gap-2 px-5 py-2.5 rounded-2xl
                           bg-gradient-to-r from-[#F7D37A] via-[#FFE88C] to-[#C9963A]
                           shadow-[0_4px_20px_rgba(201,150,58,.5),inset_0_1px_0_rgba(255,255,255,.3)]">
              <span className="text-xl">🏆</span>
              <div className="text-center">
                <p className="text-[10px] text-[#6b3a00] font-bold leading-tight">รวมมูลค่า</p>
                <p className="text-xl font-black text-[#3a1a00] leading-tight tracking-tight">
                  2,400,000
                  <span className="text-sm ml-1">บาท</span>
                </p>
              </div>
              <span className="text-xl">🏆</span>
              {/* Shimmer */}
              <div className="absolute inset-0 rounded-2xl overflow-hidden btn-shimmer" />
            </div>
          </motion.div>

          {/* Three pillars: เฮง เฮ เปย์ — matching poster */}
          <div className="flex justify-center gap-3 px-6 pb-4">
            {[
              { emoji: '🎰', label: 'เฮง', desc: 'กินร้านนี้แล้ว\nวับไชค เฮง', color: '#C41E3A' },
              { emoji: '🎊', label: 'เฮ',  desc: 'ร้าน ลุ้นรวย\nเตรียม เฮ', color: '#B8860B' },
              { emoji: '💰', label: 'เปย์', desc: 'ร้านเข้า ลูกค้า\nลุ้นหมีปรุง เปย์', color: '#C41E3A' },
            ].map((item, i) => (
              <motion.div
                key={item.label}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.5 + i * 0.1 }}
                className="flex-1 text-center"
              >
                <div className="w-12 h-12 mx-auto rounded-xl
                               bg-gradient-to-b from-[rgba(247,211,122,.2)] to-[rgba(201,150,58,.08)]
                               border border-[rgba(201,150,58,.25)]
                               flex items-center justify-center text-2xl mb-1.5">
                  {item.emoji}
                </div>
                <p className="text-base font-black text-[#F7D37A]">{item.label}</p>
                <p className="text-[9px] text-[rgba(251,240,200,.45)] leading-tight whitespace-pre-line mt-0.5">
                  {item.desc}
                </p>
              </motion.div>
            ))}
          </div>

          {/* Divider */}
          <div className="h-px mx-6 bg-gradient-to-r from-transparent via-[rgba(201,150,58,.25)] to-transparent" />

          {/* Login section */}
          <div className="px-6 py-5 space-y-3">
            <p className="text-center text-sm text-[rgba(251,240,200,.6)] leading-relaxed">
              สแกน QR ที่ร้านค้าเพื่อลุ้นรางวัล<br />ทั้งลูกค้าและร้านค้าได้รางวัล!
            </p>

            {/* Error message */}
            <AnimatePresence>
              {error && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  exit={{ opacity: 0, height: 0 }}
                  className="bg-red-500/20 border border-red-500/30 rounded-xl px-4 py-2.5 text-center"
                >
                  <p className="text-xs text-red-200">{error}</p>
                </motion.div>
              )}
            </AnimatePresence>

            {/* Privacy */}
            <div className="flex gap-3 items-start bg-black/20 border border-[rgba(201,150,58,.1)]
                            rounded-xl p-3">
              <span className="text-lg flex-shrink-0 mt-0.5">🔒</span>
              <span className="text-xs text-[rgba(251,240,200,.45)] leading-relaxed">
                ระบบใช้เฉพาะชื่อและรูปโปรไฟล์จาก LINE
                ไม่มีการโพสต์หรือส่งข้อความหาเพื่อน
              </span>
            </div>

            {/* LINE Login button */}
            <button
              onClick={handleLineLogin}
              className="relative w-full py-4 rounded-2xl overflow-hidden
                         bg-[#06C755] text-white font-extrabold text-lg
                         shadow-[0_6px_24px_rgba(6,199,85,.4)]
                         active:scale-[.97] transition-transform
                         flex items-center justify-center gap-3 btn-shimmer"
            >
              <svg width="28" height="28" viewBox="0 0 40 40" className="flex-shrink-0">
                <rect width="40" height="40" rx="8" fill="white" fillOpacity=".15"/>
                <path d="M20 4C11.16 4 4 10.27 4 18.03c0 7.27 6.45 13.35 15.16 14.49.59.12 1.39.38 1.59.89.18.45.12 1.17.06 1.64l-.26 1.58c-.08.45-.36 1.78 1.57.97 1.93-.82 10.42-6.14 14.22-10.51C38.56 24.19 36 21.22 36 18.03 36 10.27 28.84 4 20 4z" fill="white"/>
                <path d="M16.5 22.5h-3.3a.72.72 0 0 1-.72-.72v-7.26a.72.72 0 0 1 1.44 0v6.54h2.58a.72.72 0 0 1 0 1.44zm2.4-.72a.72.72 0 0 1-1.44 0v-7.26a.72.72 0 0 1 1.44 0v7.26zm7.26 0a.72.72 0 0 1-.7.72h-.02a.72.72 0 0 1-.6-.31L21.72 18v3.78a.72.72 0 0 1-1.44 0v-7.26a.72.72 0 0 1 .7-.72h.02a.72.72 0 0 1 .6.31l3.12 4.62v-4.21a.72.72 0 0 1 1.44 0v7.26zm4.68.72h-3.3a.72.72 0 0 1-.72-.72v-7.26a.72.72 0 0 1 .72-.72h3.3a.72.72 0 0 1 0 1.44H28.26v2.16h2.52a.72.72 0 0 1 0 1.44h-2.52v2.22h3.3a.72.72 0 0 1-.72 1.44z" fill="#06C755"/>
              </svg>
              เข้าสู่ระบบด้วย LINE
            </button>

            <p className="text-center text-[10px] text-[rgba(251,240,200,.25)] leading-relaxed">
              การเข้าสู่ระบบถือว่าคุณยอมรับ{' '}
              <a href="#" className="text-[rgba(247,211,122,.35)]">นโยบายความเป็นส่วนตัว</a>
              {' '}และ{' '}
              <a href="#" className="text-[rgba(247,211,122,.35)]">เงื่อนไขการใช้งาน</a>
            </p>
          </div>
        </div>

        {/* Bottom brand text */}
        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.8 }}
          className="text-center text-[11px] text-[rgba(251,240,200,.25)] mt-4"
        >
          powered by <span className="text-[rgba(247,211,122,.4)] font-semibold">ปังจัง.com</span>
        </motion.p>
      </motion.div>
    </main>
  )
}
